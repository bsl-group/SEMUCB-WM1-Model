#ifndef _CONSTANTS_H_

#define _CONSTANTS_H_

#define R_EARTH_KM 6371.0

#endif
