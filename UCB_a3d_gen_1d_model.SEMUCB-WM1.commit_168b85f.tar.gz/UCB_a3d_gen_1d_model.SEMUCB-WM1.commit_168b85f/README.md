# Local Minos-style 1D models for SEMUCB-WM1

This code provides basic functionality for extracting 1D models from the
SEMUCB-WM1 in the minos tabular format at specific (lat, lon) locations.

One could, for example, use this code for evaluating "local" surface-wave
dispersion at specific locations.

## Building

On system with `gcc` installed, you should be able to simply run `make`. After
that, there should be a `gen_1d_model` binary in the `bin/` subdirectory.  If
`gcc` (or, say, something which is very good at pretending to be `gcc`) is not
available, you will likely need to modify the compiler specified by the `CC`
variable in the `config` section of the `Makefile`.

## Running

Run `bin/gen_1d_model -h` for a brief synopsis. What you will need to supply in
order to produce 1D models is a text file containing three columns:

    <location_name> <lon> <lat>
    <location_name> <lon> <lat>
     ... snip ...

where `location_name` is a unique string of your choosing containing no
whitespace characters used to identify a particular location and the longitude
and latitude are in degrees (the latter is assumed to be *geocentric* - see
below).

You can specify the name of this file with the `-i` flag or use the default
name of `locations.dat`.

For each row in the input file, a new 1D output file in minos format will be
produced, named `output_base.location_name`. The `output_base` can be specified
with the `-o` option, or the default will be used (`model_1D`).

## Assumptions

For simplicity, this program makes a couple of key assumptions:

1. It is assumed that you are looking at long periods. In so doing, while it
   does produce 1D models reflecting local Moho and crustal model variation in
   our smoothed crustal layer as well a water layer where present, it does not
   account for local free surface topography (other than that required to
   provide a water layer).
2. Input latitudes are assumed to be in geocentric, not geographic,
   coordinates. Thus, if this matters for your application, be sure to make
   this correction before generating your input file.

Indeed, assumption (1) is directly related to the manner in which the
SEMUCB-WM1 model was created (using surface wave data down to 60 s and body
wave data down to 32 s), and is inherent to the use of a smoothed anisotropic
crustal layer in this manner.

## SEMum2

Because the SEMUCB-WM1 model is based on SEMum2 (i.e. the latter was the
starting model), we also include the SEMum2 model files for evaluation.

In order to instead use the SEMum2 model to construct 1D profiles, simply
redirect the `data` symlink to the `data.semum2` directory (instead of the
default, `data.semucb`).
