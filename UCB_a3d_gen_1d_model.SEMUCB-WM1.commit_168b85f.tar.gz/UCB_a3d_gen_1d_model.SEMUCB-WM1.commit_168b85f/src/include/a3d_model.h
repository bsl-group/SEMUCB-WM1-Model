
#ifndef _A3D_MODEL_H
#define _A3D_MODEL_H

#ifndef _CMINOS_H
#include <cminos.h>
#endif

#define A3D_MAX_PARAMS 2
#define A3D_MAX_DISCON 1
#define A3D_MAX_BSPLINES 26
#define A3D_MAX_SSPLINES 10300

struct a3d_grid_vol
{
  int num_bspl, num_sspl;
  float bspl_knots[A3D_MAX_BSPLINES];
  double sspl_knots[2 * A3D_MAX_SSPLINES];
  int sspl_level[A3D_MAX_SSPLINES];
};
typedef struct a3d_grid_vol a3d_grid_vol_t;  

struct a3d_grid_surf
{
  int num_sspl;
  double sspl_knots[2 * A3D_MAX_SSPLINES];
  int sspl_level[A3D_MAX_SSPLINES];
};
typedef struct a3d_grid_surf a3d_grid_surf_t; 

struct a3d_model
{
  int np, nd;
  char descp[A3D_MAX_PARAMS];
  char descd[A3D_MAX_DISCON];
  a3d_grid_vol_t gridp[A3D_MAX_PARAMS];
  a3d_grid_surf_t gridd[A3D_MAX_DISCON];
  double p[A3D_MAX_PARAMS][A3D_MAX_BSPLINES][A3D_MAX_SSPLINES];
  double d[A3D_MAX_DISCON][A3D_MAX_SSPLINES];
};
typedef struct a3d_model a3d_model_t;


/* externally callable function prototypes */

void
load_a3d_model( char *data_dir, char *model_file_name, a3d_model_t *a3d );

void
get_pertubed_profile_SX( a3d_model_t *a3d_SX, double lat, double lon, double *dlnVs_spl, double *dlnXi_spl );

void
perturb_1d_model_SX( model_t *ref, a3d_model_t *a3d, double r_min, double r_max, double *dlnVs_spl, double *dlnXi_spl );

int
kron_sspl_AIJ_SX( a3d_model_t *a3d_SX, double *Mat, double *A, int *IJ, int i_0, int m_Mat, double lat, double lon );

#endif
