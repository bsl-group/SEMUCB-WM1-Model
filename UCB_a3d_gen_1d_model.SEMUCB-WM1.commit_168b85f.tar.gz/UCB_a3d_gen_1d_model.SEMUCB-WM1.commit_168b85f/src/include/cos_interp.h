
#ifndef _COS_INTERP_H
#define _COS_INTERP_H

double
cos_interp(double *lats, double *lons, double *field, int n, double lat, double lon, double width);

#endif

