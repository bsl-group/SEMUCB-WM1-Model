
#ifndef _GLL_H
#define _GLL_H

#ifndef _CMINOS_H
#include <cminos.h>
#endif

/* Gauss-Lobatto-Legendre quadrature degree and nodes */
#define DEGREE_GLL 4

/* Model generation */
void add_gll_layer( model_t *sref, model_t *dref, double *vs_unique, double *xi_unique, double moho, double topo );

#endif
