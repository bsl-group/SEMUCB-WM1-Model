
#ifndef _PARTIAL_H
#define _PARTIAL_H

#ifndef _CMINOS_H
#include <cminos.h>
#endif

#ifndef _A3D_MODEL_H
#include <a3d_model.h>
#endif

#ifndef _GLL_H
#include <gll.h>
#endif

/* minimum radius for application of b-spline perturbations */
#define R_PERTB_MIN 3480000.0

/* range of b-spline coefficients for which to calculate partials 
 * N.B. these count from zero, unlike pretty much everything else ucb ... */
/* Now defined in the Makefile for naming the executable */
/* #define BSPL_PARTIAL_MIN 9
   #define BSPL_PARTIAL_MAX 19 */

/* derived compile-time macros */
#define NUM_BSPLINES_INVERT ( BSPL_PARTIAL_MAX - BSPL_PARTIAL_MIN + 1 )
#define NUM_PARAMETERS ( 2 * NUM_BSPLINES_INVERT )

void
generate_jacobians( model_t *sref, a3d_model_t *a3d, double *dlnVs_spl, double *dlnXi_spl, 
		    double *unique_vs, double *unique_xi, double topo, double moho, 
		    double *T, int num_periods, double *J_R_U, double *J_L_U, double *J_R_c, double *J_L_c, 
		    double *Usyn_R, double *Usyn_L, double *csyn_R, double *csyn_L,
		    int rank, FILE *f_log );

#endif
