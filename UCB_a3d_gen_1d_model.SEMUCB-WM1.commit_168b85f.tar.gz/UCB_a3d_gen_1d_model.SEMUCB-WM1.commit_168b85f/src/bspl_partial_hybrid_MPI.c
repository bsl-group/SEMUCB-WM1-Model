#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <cminos.h>
#include <gll.h>
#include <a3d_model.h>
#include <partial.h>
#include <mpi.h>

#define min(a,b) ((a)>(b)?(b):(a))

/* period range */
#define NUM_PERIODS 13
double T[] = {25,30,35,40,45,50,60,70,80,90,100,125,150};

/* NUM_PARAMETERS is defined in include/partial.h */
#define JACOBIAN_SIZE ( NUM_PARAMETERS * NUM_PERIODS )

/* input and output files */
#define REF_MODEL_NAME "lu_model"          /* input: 1D reference model */
#define A3D_MODEL_NAME "lu_a3d"            /* input: A3d model */
#define CRUSTAL_MODEL_NAME "lu_crust"      /* input: crustal model */
#define PARTIALS_ASCII_FILE "lu_partials"  /* output: dispersion predictions
                                              and partials */

/* notes:
 * - the locations of the computed partial derivatives will be the same as
 *   those supplied in the crustal model file
 * - TODO: there are a lot of un-checked mallocs in here (this was written in
 *   kind of a hurry); it would be good to check them for NULL
 */

/* number of models in each "chunk" of work distributed to worker processes */
#define DEFAULT_MODEL_CHUNK_SIZE 11

int
main( int argc, char **argv )
{
  FILE *f_model, *f_log = stdout, *f_partials;
  model_t ref;
  a3d_model_t a3d;
  int rank, size;
  int num_models, num_parameters;
  int *model_map, model_chunk_start, model_chunk_size = 0;
  double wt0, wt1;
  double *lats, *lons, *crust_vs, *crust_xi, *moho, *topo;
  double dlnVs_spl[A3D_MAX_BSPLINES], dlnXi_spl[A3D_MAX_BSPLINES];
  double *J_R_U, *J_L_U, *Usyn_R, *Usyn_L;
  double *J_R_c, *J_L_c, *csyn_R, *csyn_L;

  /* initialize mpi */
  MPI_Init( &argc, &argv );
  MPI_Comm_rank( MPI_COMM_WORLD, &rank );
  MPI_Comm_size( MPI_COMM_WORLD, &size );

  /* load the 1D reference model */
  if ( rank == 0 )
    {
      load_model( REF_MODEL_NAME, &ref );
      printf( "[%4.4i] Read in the reference model\n", rank );
    }
  MPI_Bcast( &ref, sizeof(ref), MPI_BYTE, 0, MPI_COMM_WORLD );

  /* load the 3D mantle model */
  if ( rank == 0 )
    {
      load_a3d_model( A3D_MODEL_NAME, &a3d );
      printf( "[%4.4i] Read in the 3D mantle model\n", rank );
    }
  MPI_Bcast( &a3d, sizeof(a3d), MPI_BYTE, 0, MPI_COMM_WORLD );

  /* open crustal model sampling file and read in profiles ...
   * these locations will serve as the evaluation points for the
   * partial derivatives calculated below */
  if ( rank == 0 )
    {
      if ( ( f_model = fopen( CRUSTAL_MODEL_NAME, "r" ) ) == NULL )
        {
          printf( "Error: cannot open model file %s - %s\n", CRUSTAL_MODEL_NAME, strerror( errno ) );
          MPI_Abort( MPI_COMM_WORLD, 1 );
        }

      if ( fscanf( f_model, "%i", &num_models ) != 1 )
        {
          printf( "Error: malformed header (model count) in %s\n", CRUSTAL_MODEL_NAME );
          MPI_Abort( MPI_COMM_WORLD, 1 );
        }
    }
  MPI_Bcast( &num_models, 1, MPI_INT, 0, MPI_COMM_WORLD );

  /* malloc vs xi moho topo */
  lats = malloc( num_models * sizeof( double ) );
  lons = malloc( num_models * sizeof( double ) );
  crust_vs = malloc( num_models * NUM_UNIQUE_VS * sizeof( double ) );
  crust_xi = malloc( num_models * NUM_UNIQUE_XI * sizeof( double ) );
  moho = malloc( num_models * sizeof( double ) );
  topo = malloc( num_models * sizeof( double ) );

  if ( rank == 0 )
    {
      /* read in vs xi moho topo */
      for ( int m = 0; m < num_models; m++ )
        {
          int nread = 0;
          nread += fscanf( f_model, "%lf", &lats[m] );
          nread += fscanf( f_model, "%lf", &lons[m] );
          for ( int ivs = 0; ivs < NUM_UNIQUE_VS; ivs++ )
            nread += fscanf( f_model, "%lf", &crust_vs[m * NUM_UNIQUE_VS + ivs] );
          for ( int ixi = 0; ixi < NUM_UNIQUE_XI; ixi++ )
            nread += fscanf( f_model, "%lf", &crust_xi[m * NUM_UNIQUE_XI + ixi] );
          nread += fscanf( f_model, "%lf", &moho[m] );
          nread += fscanf( f_model, "%lf", &topo[m] );
          if ( nread != 4 + NUM_UNIQUE_VS + NUM_UNIQUE_XI )
            {
              printf( "Error: incomplete crustal model file %s (model %i / %i)\n", CRUSTAL_MODEL_NAME,
                      m, num_models );
              MPI_Abort( MPI_COMM_WORLD, 1 );
            }
        }
      fclose( f_model );
      printf( "[%4.4i] Read in %i crustal models\n", rank, num_models );
    }
  MPI_Bcast( lats, num_models, MPI_DOUBLE, 0, MPI_COMM_WORLD );
  MPI_Bcast( lons, num_models, MPI_DOUBLE, 0, MPI_COMM_WORLD );
  MPI_Bcast( crust_vs, NUM_UNIQUE_VS * num_models, MPI_DOUBLE, 0, MPI_COMM_WORLD );
  MPI_Bcast( crust_xi, NUM_UNIQUE_XI * num_models, MPI_DOUBLE, 0, MPI_COMM_WORLD );
  MPI_Bcast( moho, num_models, MPI_DOUBLE, 0, MPI_COMM_WORLD );
  MPI_Bcast( topo, num_models, MPI_DOUBLE, 0, MPI_COMM_WORLD );

  /* num_parameters now fixed at compile time */
  num_parameters = NUM_PARAMETERS;

  if ( rank == 0 )
    printf( "[%4.4i] num_parameters = %i\n", rank, num_parameters );

  /* everyone wait */
  MPI_Barrier( MPI_COMM_WORLD );

  /* if root, distribute models, else accept models and calculate partials */
  if ( rank == 0 )
    {
      MPI_Status status_ready, status_data;
      int chunk = 0, num_done = 0, done = 0, ready;

      /* allocate model map and storage for partials and synthetics */
      model_map = malloc( size * sizeof(int) );
#if !defined(FORWARD_ONLY)
      J_R_U    = malloc( num_models * JACOBIAN_SIZE * sizeof(double) );
      J_L_U    = malloc( num_models * JACOBIAN_SIZE * sizeof(double) );
      J_R_c    = malloc( num_models * JACOBIAN_SIZE * sizeof(double) );
      J_L_c    = malloc( num_models * JACOBIAN_SIZE * sizeof(double) );
#else
      J_R_U    = NULL;
      J_L_U    = NULL;
      J_R_c    = NULL;
      J_L_c    = NULL;
#endif
      Usyn_R = malloc( num_models * NUM_PERIODS * sizeof(double) );
      Usyn_L = malloc( num_models * NUM_PERIODS * sizeof(double) );
      csyn_R = malloc( num_models * NUM_PERIODS * sizeof(double) );
      csyn_L = malloc( num_models * NUM_PERIODS * sizeof(double) );

      /* loop over model chunks until all processors in the pool are "done" */
      while ( num_done < size - 1 )
        {
          /* catch the first free processor in the receive buffer */
          MPI_Recv( &ready, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status_ready );
#ifdef DEBUG
          fprintf( f_log, "[%4.4i] Received ready message %i from %i\n", rank, ready, status_ready.MPI_SOURCE );
#endif

          /* if the processor needs to return synthetics and partials, let it */
          if ( ready > 0 )
            {
              int u_start = model_map[status_ready.MPI_SOURCE] * NUM_PERIODS;
#if !defined(FORWARD_ONLY)
              int j_start = model_map[status_ready.MPI_SOURCE] * JACOBIAN_SIZE;
              MPI_Recv( &J_R_U[j_start], ready * JACOBIAN_SIZE, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
              MPI_Recv( &J_L_U[j_start], ready * JACOBIAN_SIZE, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
              MPI_Recv( &J_R_c[j_start], ready * JACOBIAN_SIZE, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
              MPI_Recv( &J_L_c[j_start], ready * JACOBIAN_SIZE, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
#endif
              MPI_Recv( &Usyn_R[u_start], ready * NUM_PERIODS, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
              MPI_Recv( &Usyn_L[u_start], ready * NUM_PERIODS, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
              MPI_Recv( &csyn_R[u_start], ready * NUM_PERIODS, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
              MPI_Recv( &csyn_L[u_start], ready * NUM_PERIODS, MPI_DOUBLE, status_ready.MPI_SOURCE,
                        MPI_ANY_TAG, MPI_COMM_WORLD, &status_data );
#ifdef DEBUG
              fprintf( f_log, "[%4.4i] Received completed chunk from %i\n", rank, status_ready.MPI_SOURCE );
#endif
            }

          /* if not all models have been sent to the processor pool, give the processor
           * we caught the next available model chunk */
          if ( ! done )
            {
              /* select the model chunk */
#ifdef DEBUG
              fprintf( f_log, "[%4.4i] Selecting chunk for %i\n", rank, status_ready.MPI_SOURCE );
#endif
              model_chunk_start = chunk * DEFAULT_MODEL_CHUNK_SIZE;
              model_chunk_size  = min( DEFAULT_MODEL_CHUNK_SIZE, num_models - model_chunk_start );

              /* check whether we have exhausted the list of models */
              if ( model_chunk_start + model_chunk_size == num_models )
                done = 1;

              /* record the index of the first model in the chunk */
              model_map[status_ready.MPI_SOURCE] = model_chunk_start;

              /* feed the chunk to the processor */
#ifdef DEBUG
              fprintf( f_log, "[%4.4i] Sending chunk of size %i to %i\n", rank, model_chunk_size, status_ready.MPI_SOURCE );
#endif
              MPI_Send( &model_chunk_size, 1, MPI_INT, status_ready.MPI_SOURCE, 0, MPI_COMM_WORLD );
              MPI_Send( &model_chunk_start, 1, MPI_INT, status_ready.MPI_SOURCE, 0, MPI_COMM_WORLD );

              /* update the chunk counter */
              chunk += 1;
            }
          else
            {
              /* we have exhausted the list of models - send each proc a zero chunk size to shut it down */
              model_chunk_size = 0;
#ifdef DEBUG
              fprintf( f_log, "[%4.4i] Sending chunk of size %i to %i\n", rank, model_chunk_size, status_ready.MPI_SOURCE );
#endif
              MPI_Send( &model_chunk_size, 1, MPI_INT, status_ready.MPI_SOURCE, 0, MPI_COMM_WORLD );

              /* update the counter of processors that have been shut down */
              num_done += 1;
            }
        }
    }
  else
    {
      /* we are in the work-pool - accept model chunks from root ... */
      MPI_Status status_ready, status_data;
      double Usyn_R_chunk[DEFAULT_MODEL_CHUNK_SIZE * NUM_PERIODS], Usyn_L_chunk[DEFAULT_MODEL_CHUNK_SIZE * NUM_PERIODS];
      double csyn_R_chunk[DEFAULT_MODEL_CHUNK_SIZE * NUM_PERIODS], csyn_L_chunk[DEFAULT_MODEL_CHUNK_SIZE * NUM_PERIODS];
#if !defined(FORWARD_ONLY)
      double J_R_U_chunk[DEFAULT_MODEL_CHUNK_SIZE * JACOBIAN_SIZE], J_L_U_chunk[DEFAULT_MODEL_CHUNK_SIZE * JACOBIAN_SIZE];
      double J_R_c_chunk[DEFAULT_MODEL_CHUNK_SIZE * JACOBIAN_SIZE], J_L_c_chunk[DEFAULT_MODEL_CHUNK_SIZE * JACOBIAN_SIZE];
#endif

      /* initialize the interaction with the root processor by sending a zero chunk-size ready message */
      MPI_Send( &model_chunk_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD );

      /* pull in the size of the first chunk */
      MPI_Recv( &model_chunk_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status_ready );

      /* loop over model chunks from root unless we are given a chunk of zero size */
      while ( model_chunk_size > 0 )
        {
          /* receive the model chunk from root */
          MPI_Recv( &model_chunk_start, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status_data );
#ifdef DEBUG
          fprintf( f_log, "[%4.4i] Received chunk of size %i from root\n", rank, model_chunk_size );
#endif

          /* calculate synthetics and partials for all models in the chunk */
#ifdef DEBUG
          fprintf( f_log, "[%4.4i] Calculating partials for models %i through %i\n",
                   rank, model_chunk_start, model_chunk_start + model_chunk_size - 1 );
#endif
          wt0 = MPI_Wtime();
          for ( int m = 0; m < model_chunk_size; m++ )
            {
              int model_match = model_chunk_start + m;
              double *J_R_U_chunk_start, *J_L_U_chunk_start;
              double *J_R_c_chunk_start, *J_L_c_chunk_start;
#if !defined(FORWARD_ONLY)
              J_R_U_chunk_start = &J_R_U_chunk[m * JACOBIAN_SIZE];
              J_L_U_chunk_start = &J_L_U_chunk[m * JACOBIAN_SIZE];
              J_R_c_chunk_start = &J_R_c_chunk[m * JACOBIAN_SIZE];
              J_L_c_chunk_start = &J_L_c_chunk[m * JACOBIAN_SIZE];
#else
              J_R_U_chunk_start = NULL;
              J_L_U_chunk_start = NULL;
              J_R_c_chunk_start = NULL;
              J_L_c_chunk_start = NULL;
#endif

              /* get the b-spline coefs from the current mantle model */
              get_pertubed_profile_SX( &a3d, lats[model_match], lons[model_match], dlnVs_spl, dlnXi_spl );

              /* calculate partial derivatives w.r.t. b-spline coefs */
              generate_jacobians( &ref, &a3d, dlnVs_spl, dlnXi_spl,
                                  &crust_vs[model_match * NUM_UNIQUE_VS], &crust_xi[model_match * NUM_UNIQUE_XI],
                                  topo[model_match], moho[model_match],
                                  T, NUM_PERIODS,
                                  J_R_U_chunk_start, J_L_U_chunk_start, J_R_c_chunk_start, J_L_c_chunk_start,
                                  &Usyn_R_chunk[m * NUM_PERIODS], &Usyn_L_chunk[m * NUM_PERIODS],
                                  &csyn_R_chunk[m * NUM_PERIODS], &csyn_L_chunk[m * NUM_PERIODS],
                                  rank, f_log );
              /* if ( m % 10 == 0 )
                printf( "[%4.4i] Current estimate for remaining chunk computation time: %f s\n",
                        rank, ( model_chunk_size - m ) * ( MPI_Wtime() - wt0 ) / (m + 1) ); */
            }
          wt1 = MPI_Wtime();

          /* return the synthetics and partials to the root processor */
          MPI_Send( &model_chunk_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD );
#if !defined(FORWARD_ONLY)
          MPI_Send( J_R_U_chunk, model_chunk_size * JACOBIAN_SIZE, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          MPI_Send( J_L_U_chunk, model_chunk_size * JACOBIAN_SIZE, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          MPI_Send( J_R_c_chunk, model_chunk_size * JACOBIAN_SIZE, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          MPI_Send( J_L_c_chunk, model_chunk_size * JACOBIAN_SIZE, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
#endif
          MPI_Send( Usyn_R_chunk, model_chunk_size * NUM_PERIODS, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          MPI_Send( Usyn_L_chunk, model_chunk_size * NUM_PERIODS, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          MPI_Send( csyn_R_chunk, model_chunk_size * NUM_PERIODS, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          MPI_Send( csyn_L_chunk, model_chunk_size * NUM_PERIODS, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD );
          fprintf( f_log, "[%4.4i] Returned chunk of size %i to root (calculation: %f s)\n", rank, model_chunk_size, wt1 - wt0);

          /* catch the next chunk, possibly of zero size */
          MPI_Recv( &model_chunk_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status_ready );
        }

      fprintf( f_log, "[%4.4i] Received zero chunk size, exiting ...\n", rank );
    }


  /* if root, write out syns and partials */
  if ( rank == 0 )
    {
      if ( ( f_partials = fopen( PARTIALS_ASCII_FILE, "w" ) ) == NULL )
        {
          printf( "Error: cannot open ascii partials file %s - %s\n", PARTIALS_ASCII_FILE, strerror( errno ) );
          MPI_Abort( MPI_COMM_WORLD, 1 );
        }
      for ( int m = 0; m < num_models; m++ )
        for ( int it = 0; it < NUM_PERIODS; it++ )
          {
            fprintf( f_partials, "%8i %10g %10g %10g %10g %10g", m, T[it],
                     Usyn_R[m * NUM_PERIODS + it], Usyn_L[m * NUM_PERIODS + it],
                     csyn_R[m * NUM_PERIODS + it], csyn_L[m * NUM_PERIODS + it] );
#if !defined(FORWARD_ONLY)
            for ( int ip = 0; ip < num_parameters; ip++ )
              fprintf( f_partials, " %10g", J_R_U[m * JACOBIAN_SIZE + ip * NUM_PERIODS + it] );
            for ( int ip = 0; ip < num_parameters; ip++ )
              fprintf( f_partials, " %10g", J_L_U[m * JACOBIAN_SIZE + ip * NUM_PERIODS + it] );
            for ( int ip = 0; ip < num_parameters; ip++ )
              fprintf( f_partials, " %10g", J_R_c[m * JACOBIAN_SIZE + ip * NUM_PERIODS + it] );
            for ( int ip = 0; ip < num_parameters; ip++ )
              fprintf( f_partials, " %10g", J_L_c[m * JACOBIAN_SIZE + ip * NUM_PERIODS + it] );
#endif
            fprintf( f_partials, "\n" );
          }
      fclose( f_partials );
    }

  /* close log file and shut down MPI */
  /* disabled: currently set to stdout */
  /* fclose( f_log ); */

  MPI_Finalize( );

  return 0;
}
