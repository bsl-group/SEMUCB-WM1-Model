#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include <a3d_model.h>
#include <cminos.h>
#include <partial.h>

#define min(a,b) ((a)>(b)?(b):(a))
#define max(a,b) ((a)>(b)?(a):(b))

#define DEG2RAD 0.017453292519943295

/* standard inter-knot distances (radians) by level */
static const double adel[] = {
  +1.106538745764405,
  +0.55326937288220250,
  +0.27576202181510406,
  +0.13788101090755203,
  +0.06894050545377602,
  +0.034557519189487726,
  +0.017278759594743863
};

/* Montagner and Anderson (1989) inter-parameter scalings */
#define MA1989_dlnVp_dlnVs 0.5
#define MA1989_dlnRho_dlnVs 0.33
#define MA1989_dlnPhi_dlnXi -1.5
#define MA1989_dlnEta_dlnXi -2.5

/* Note: spl() defined in splines/spl.c with K & R style prototype, do not
 * supply parameter types here - just the return type */
extern float spl( );

void
load_a3d_model( char *data_dir, char *model_file_name, a3d_model_t *a3d )
{
  FILE *f_in, *f_sspl;
  char sspl_file_name[256];
  int num_sspl;

  if ( ( f_in = fopen( model_file_name, "r" ) ) == NULL )
    {
      printf( "[ load_a3d_model ] Error: cannot open model file %s - %s\n", model_file_name, strerror( errno ) );
      exit( 1 );
    }

  if ( fscanf( f_in, "%i\n", &a3d->np ) != 1 )
    {
      printf( "[ load_a3d_model ] Error: malformed header in %s (parameter count)\n", model_file_name );
      exit(EXIT_FAILURE);
    }
  for ( int p = 0; p < a3d->np; p++ )
    {
      if ( fscanf( f_in, "%i %i %c\n",
                   &a3d->gridp[p].num_sspl,
                   &a3d->gridp[p].num_bspl,
                   &a3d->descp[p] ) != 3 )
        {
          printf( "[ load_a3d_model ] Error: malformed header in %s (parameter description %i)\n", model_file_name, p );
          exit(EXIT_FAILURE);
        }
      sprintf( sspl_file_name, "%s/grid.%c", data_dir, a3d->descp[p] );
      if ( ( f_sspl = fopen( sspl_file_name, "r" ) ) == NULL )
        {
          printf( "[ load_a3d_model ] Error: cannot open spherical spline knot file %s - %s\n",
                  sspl_file_name, strerror( errno ) );
          exit( 1 );
        }
      if ( fscanf( f_sspl, "%i\n", &num_sspl ) != 1 )
        {
          printf( "[ load_a3d_model ] Error: malformed header in %s\n", sspl_file_name );
          exit(EXIT_FAILURE);
        }
      if ( num_sspl != a3d->gridp[p].num_sspl )
        {
          printf( "[ load_a3d_model ] Error: num_sspl %i in %s does not match A3d file\n", num_sspl, sspl_file_name );
          exit(EXIT_FAILURE);
        }
      for ( int s = 0; s < a3d->gridp[p].num_sspl; s++ )
        {
          if ( fscanf( f_sspl, "%lf %lf %i\n",
                       &a3d->gridp[p].sspl_knots[2 * s + 1],
                       &a3d->gridp[p].sspl_knots[2 * s],
                       &a3d->gridp[p].sspl_level[s] ) != 3 )
            {
              printf( "[ load_a3d_model ] Error: malformed grid file %s at knot %i\n", sspl_file_name, s );
              exit(EXIT_FAILURE);
            }
        }
      fclose( f_sspl );
    }

  if ( fscanf( f_in, "%i\n", &a3d->nd ) !=  1 )
    {
      printf( "[ load_a3d_model ] Error: malformed header in %s (discon count)\n", model_file_name );
      exit(EXIT_FAILURE);
    }
  for ( int d = 0; d < a3d->nd; d++ )
    {
      if ( fscanf( f_in, "%i %c\n", &a3d->gridd[d].num_sspl, &a3d->descd[d] ) != 2 )
        {
          printf( "[ load_a3d_model ] Error: malformed header in %s (discon description %i)\n", model_file_name, d );
          exit(EXIT_FAILURE);
        }
      sprintf( sspl_file_name, "%s/grid.%c", data_dir, a3d->descd[d] );
      if ( ( f_sspl = fopen( sspl_file_name, "r" ) ) == NULL )
        {
          printf( "[ load_a3d_model ] Error: cannot open spherical spline knot file %s - %s\n",
                  sspl_file_name, strerror( errno ) );
          exit( 1 );
        }
      if ( fscanf( f_sspl, "%i\n", &num_sspl ) != 1 )
        {
          printf( "[ load_a3d_model ] Error: malformed header in %s\n", sspl_file_name );
          exit(EXIT_FAILURE);
        }
      if ( num_sspl != a3d->gridd[d].num_sspl )
        {
          printf( "[ load_a3d_model ] Error: num_sspl %i in %s does not match A3d file\n", num_sspl, sspl_file_name );
          exit(EXIT_FAILURE);
        }
      for ( int s = 0; s < a3d->gridd[d].num_sspl; s++ )
        {
          if ( fscanf( f_in, "%lf %lf %i\n",
                       &a3d->gridd[d].sspl_knots[2 * s + 1],
                       &a3d->gridd[d].sspl_knots[2 * s],
                       &a3d->gridd[d].sspl_level[s] ) != 3 )
            {
              printf( "[ load_a3d_model ] Error: malformed grid file %s at knot %i\n", sspl_file_name, s );
              exit(EXIT_FAILURE);
            }
        }
      fclose( f_sspl );
    }

  for ( int k = 0; k < a3d->gridp[0].num_bspl; k++ )
    if ( fscanf( f_in, "%f", &a3d->gridp[0].bspl_knots[k] ) != 1 )
      {
        printf( "[ load_a3d_model ] Error: could not read b-spline knot %i from %s\n", k + 1, model_file_name );
        exit(EXIT_FAILURE);
      }
  for ( int p = 1; p < a3d->np; p++ )
    for ( int k = 0; k < a3d->gridp[0].num_bspl; k++ )
      a3d->gridp[p].bspl_knots[k] = a3d->gridp[0].bspl_knots[k];

  for ( int p = 0; p < a3d->np; p++ )
    for ( int k = 0; k < a3d->gridp[p].num_bspl; k++ )
      for ( int s = 0; s < a3d->gridp[p].num_sspl; s++ )
        if ( fscanf( f_in, "%lf", &a3d->p[p][k][s] ) != 1 )
          {
            printf( "[ load_a3d_model ] Error: could not read model coefficient for param %i, b-spline %i, spherical spline %i\n", p, k, s );
            exit(EXIT_FAILURE);
          }

  for ( int d = 0; d < a3d->nd; d++ )
    for ( int s = 0; s < a3d->gridd[d].num_sspl; s++ )
      if ( fscanf( f_in, "%lf", &a3d->d[d][s] ) != 1 )
        {
          printf( "[ load_a3d_model ] Error: could not read model coefficient for discon %i, spherical spline %i\n", d, s );
          exit(EXIT_FAILURE);
        }

  fclose( f_in );
}


void
perturb_1d_model_SX( model_t *ref, a3d_model_t *a3d, double r_min, double r_max, double *dlnVs_spl, double *dlnXi_spl )
{
  /* assuming Vs and Xi use the same B-spline knots */
  for ( int l = 0; l < ref->npts; l++ )
    {
      double bspl, vp_iso, vs_iso, phi, xi, eta, rho, dlnVs = 0.0, dlnXi = 0.0;
      if ( ref->r[l] < r_min || ref->r[l] > r_max )
        continue;
      /* make sure we hit the right side of any discons */
      if ( ( ref->r[l] == r_min && ref->r[l+1] == r_min ) ||
           ( ref->r[l] == r_max && ref->r[l-1] == r_max ) )
        continue;
      for ( int k = 0; k < a3d->gridp[0].num_bspl; k++ )
        {
          int k_min = max(0, k - 2), k_max = min(a3d->gridp[0].num_bspl - 1, k + 2);
          if ( ref->r[l] >= 1000.0 * a3d->gridp[0].bspl_knots[k_min] &&
               ref->r[l] <= 1000.0 * a3d->gridp[0].bspl_knots[k_max] )
            {
              bspl = (double) spl( k, a3d->gridp[0].num_bspl, a3d->gridp[0].bspl_knots, 0.001 * ref->r[l] );
              dlnVs  += dlnVs_spl[k] * bspl;
              dlnXi  += dlnXi_spl[k] * bspl;
            }
        }
      vp_iso = ( 1.0 + dlnVs * MA1989_dlnVp_dlnVs ) *
        sqrt( ( ref->vpv[l] * ref->vpv[l] + 4.0 * ref->vph[l] * ref->vph[l] ) / 5.0 );
      vs_iso = ( 1.0 + dlnVs ) * sqrt( ( 2.0 * ref->vsv[l] * ref->vsv[l] + ref->vsh[l] * ref->vsh[l] ) / 3.0 );
      rho    = ( 1.0 + dlnVs * MA1989_dlnRho_dlnVs ) * ref->rho[l];
      phi    = ( 1.0 + dlnXi * MA1989_dlnPhi_dlnXi ) * ( ref->vpv[l] * ref->vpv[l] ) / ( ref->vph[l] * ref->vph[l] );
      xi     = ( 1.0 + dlnXi ) * ( ref->vsh[l] * ref->vsh[l] ) / ( ref->vsv[l] * ref->vsv[l] );
      eta    = ( 1.0 + dlnXi * MA1989_dlnEta_dlnXi ) * ref->eta[l];
      ref->rho[l] = rho;
      ref->vph[l] = sqrt( 5.0 * vp_iso * vp_iso / ( phi + 4.0 ) );
      ref->vpv[l] = sqrt( phi * ref->vph[l] * ref->vph[l] );
      ref->vsv[l] = sqrt( 3.0 * vs_iso * vs_iso / ( xi + 2.0 ) );
      ref->vsh[l] = sqrt( xi * ref->vsv[l] * ref->vsv[l] );
      ref->eta[l] = eta;
    }
}


static double
haversin( double theta )
{
  return 0.5 * ( 1.0 - cos( theta ) );
}


static double
dist( double lat0, double lon0, double lat1, double lon1 )
{
  return 2.0 * asin( sqrt( haversin( lat1 - lat0 ) + cos( lat1 ) *  cos( lat0 ) * haversin( lon1 - lon0 ) ) );
}


void
evaluate_sspl( double *sspl_knots, double *sspl_values, int num_sspl, int *sspl_levels, double lat, double lon )
{
  for ( int s = 0; s < num_sspl; s++ )
    {
      /* average inter-knot spacing (adel already radians) */
      double d_avg = adel[sspl_levels[s] - 1];
      /* calculated great circle distance between knots */
      double d = dist( DEG2RAD * sspl_knots[2 * s], DEG2RAD * sspl_knots[2 * s + 1], DEG2RAD * lat, DEG2RAD * lon );
      if ( d <= d_avg )
        sspl_values[s] = ( 0.75 * ( d / d_avg ) * ( d / d_avg ) * ( d / d_avg ) - 1.5 * ( d / d_avg ) * ( d / d_avg ) + 1.0 );
      else if ( d <= 2 * d_avg )
        sspl_values[s] = 0.25 * ( 2.0 - d / d_avg ) * ( 2.0 - d / d_avg ) * ( 2.0 - d / d_avg );
      else
        sspl_values[s] = 0.0;
    }
}


void
get_pertubed_profile_SX( a3d_model_t *a3d_SX, double lat, double lon, double *dlnVs_spl, double *dlnXi_spl )
{
  /* assuming Vs and Xi use the same B-spline knots */
  double sspl_S[A3D_MAX_SSPLINES], sspl_X[A3D_MAX_SSPLINES];
  evaluate_sspl( a3d_SX->gridp[0].sspl_knots, sspl_S, a3d_SX->gridp[0].num_sspl, a3d_SX->gridp[0].sspl_level, lat, lon );
  evaluate_sspl( a3d_SX->gridp[1].sspl_knots, sspl_X, a3d_SX->gridp[1].num_sspl, a3d_SX->gridp[1].sspl_level, lat, lon );
  for ( int k = 0; k < a3d_SX->gridp[0].num_bspl; k++ )
    {
      dlnVs_spl[k] = dlnXi_spl[k] = 0.0;
      for ( int s = 0; s < a3d_SX->gridp[0].num_sspl; s++ )
        dlnVs_spl[k] += a3d_SX->p[0][k][s] * sspl_S[s];
      for ( int s = 0; s < a3d_SX->gridp[1].num_sspl; s++ )
        dlnXi_spl[k] += a3d_SX->p[1][k][s] * sspl_X[s];
    }
}
