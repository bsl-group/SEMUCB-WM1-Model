#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "cminos.h"
#include "a3d_model.h"
#include "gll.h"
#include "cos_interp.h"

/* static data file names */
#define MODEL_DATA_DIR "data"
#define REF_MODEL_NAME "data/model.ref"     /* input: 1D reference model */
#define A3D_MODEL_NAME "data/model.A3d"     /* input: A3d model */
#define CRUSTAL_MODEL_NAME "data/crust.dat" /* input: crustal model */

/* width of cosine cap used to interpolate crust (degrees) */
#define CRUST_INTERP_WIDTH_DEG 2.0

/* minimum radius to apply mantle model perturbation (meters) */
#define R_PERTB_MIN 3480000.0

char default_in_file[] = "locations.dat";
char default_out_file_base[] = "model_1D";

static void
usage(const char *a0)
{
  printf("\nUsage: %s [-i input_locations_file] [-o output_base]\n\n"
         "  Notes\n"
         "  =====\n"
         "    * input locations file expects a three column format:\n"
         "        <location_name> <lon> <lat>\n"
         "      where location_name is a string containing no whitespace\n"
         "    * output 1D models will be stored to\n"
         "        <output_base>.<location_name>\n"
         "    * if unspecified, the default input location file is %s\n"
         "    * if unspecified, the default output location base is %s\n\n",
         a0, default_in_file, default_out_file_base);
}

int
main(int argc, char **argv)
{
  model_t ref, ref_local;
  a3d_model_t a3d;
  int num_models;
  double *lats, *lons, *crust_vs, *crust_xi, *moho, *topo;
  double lon, lat, local_moho, local_topo;
  double dlnVs_spl[A3D_MAX_BSPLINES], dlnXi_spl[A3D_MAX_BSPLINES];
  double local_vs[NUM_UNIQUE_VS], local_xi[NUM_UNIQUE_XI];
  char c, *in_file, *out_file_base, *out_filename, loc_name[65];
  size_t out_filename_len;
  FILE *f_in, *f_crust;

  in_file = default_in_file;
  out_file_base = default_out_file_base;

  while ((c = getopt(argc, argv, "i:o:h")) != -1) {
    switch (c) {
      case 'i':
        in_file = optarg;
        break;
      case 'o':
        out_file_base = optarg;
        break;
      case 'h':
        usage(argv[0]);
        exit(EXIT_SUCCESS);
      default:
        usage(argv[0]);
        exit(EXIT_FAILURE);
    }
  }

  load_model(REF_MODEL_NAME, &ref);
  load_a3d_model(MODEL_DATA_DIR, A3D_MODEL_NAME, &a3d);

  f_crust = fopen(CRUSTAL_MODEL_NAME, "r");
  if (f_crust == NULL) {
    printf("error: cannot open model file %s - %s\n", CRUSTAL_MODEL_NAME, strerror(errno));
    exit(EXIT_FAILURE);
  }
  if (fscanf(f_crust, "%i", &num_models) != 1) {
    printf("error: malformed header (model count) in %s\n", CRUSTAL_MODEL_NAME);
    exit(EXIT_FAILURE);
  }

  /* malloc vs xi moho topo */
  lats = malloc(num_models * sizeof(double));
  if (lats == NULL) {
    printf("error: could not allocate lats for %i crustal models - %s\n", num_models, strerror(errno));
    exit(EXIT_FAILURE);
  }
  lons = malloc(num_models * sizeof(double));
  if (lons == NULL) {
    printf("error: could not allocate lons for %i crustal models - %s\n", num_models, strerror(errno));
    exit(EXIT_FAILURE);
  }
  crust_vs = malloc(num_models * NUM_UNIQUE_VS * sizeof(double));
  if (crust_vs == NULL) {
    printf("error: could not allocate crust_vs for %i crustal models - %s\n", num_models, strerror(errno));
    exit(EXIT_FAILURE);
  }
  crust_xi = malloc(num_models * NUM_UNIQUE_XI * sizeof(double));
  if (crust_xi == NULL) {
    printf("error: could not allocate crust_xi for %i crustal models - %s\n", num_models, strerror(errno));
    exit(EXIT_FAILURE);
  }
  moho = malloc(num_models * sizeof(double));
  if (moho == NULL) {
    printf("error: could not allocate moho for %i crustal models - %s\n", num_models, strerror(errno));
    exit(EXIT_FAILURE);
  }
  topo = malloc(num_models * sizeof(double));
  if (topo == NULL) {
    printf("error: could not allocate topo for %i crustal models - %s\n", num_models, strerror(errno));
    exit(EXIT_FAILURE);
  }

  for ( int m = 0; m < num_models; m++ ) {
    int nread = 0;
    nread += fscanf( f_crust, "%lf", &lats[m] );
    nread += fscanf( f_crust, "%lf", &lons[m] );
    if (lons[m] < 0)
      lons[m] += 360.0;
    for ( int ivs = 0; ivs < NUM_UNIQUE_VS; ivs++ )
      nread += fscanf( f_crust, "%lf", &crust_vs[num_models * ivs + m] );
    for ( int ixi = 0; ixi < NUM_UNIQUE_XI; ixi++ )
      nread += fscanf( f_crust, "%lf", &crust_xi[num_models * ixi + m] );
    nread += fscanf( f_crust, "%lf", &moho[m] );
    nread += fscanf( f_crust, "%lf", &topo[m] );
    if ( nread != 4 + NUM_UNIQUE_VS + NUM_UNIQUE_XI ) {
      printf( "error: incomplete crustal model file %s (model %i / %i)\n", CRUSTAL_MODEL_NAME, m, num_models );
      exit(EXIT_FAILURE);
    }
  }
  fclose( f_crust );

  f_in = fopen(in_file, "r");
  if (f_in == NULL) {
    printf("error: cannot open location file %s - %s\n", in_file, strerror(errno));
    exit(EXIT_FAILURE);
  }

  while (fscanf(f_in, "%64s %lf %lf\n", loc_name, &lon, &lat) == 3) {
    if (lon > 360.0 || lon < - 180.0) {
      printf("error: bad longitude %f\n", lon);
      exit(EXIT_FAILURE);
    }
    if (lat > 90.0 || lat < - 90.0) {
      printf("error: bad latitude %f\n", lat);
      exit(EXIT_FAILURE);
    }

    if (lon < 0.0)
      lon += 360.0;

    get_pertubed_profile_SX(&a3d, lat, lon, dlnVs_spl, dlnXi_spl);

    local_moho = cos_interp(lats, lons, moho, num_models, lat, lon, CRUST_INTERP_WIDTH_DEG);
    local_topo = cos_interp(lats, lons, topo, num_models, lat, lon, CRUST_INTERP_WIDTH_DEG);
    for (int i = 0; i < NUM_UNIQUE_VS; i++)
      local_vs[i] = cos_interp(lats, lons, &crust_vs[i * num_models], num_models, lat, lon, CRUST_INTERP_WIDTH_DEG);
    for (int i = 0; i < NUM_UNIQUE_XI; i++)
      local_xi[i] = cos_interp(lats, lons, &crust_xi[i * num_models], num_models, lat, lon, CRUST_INTERP_WIDTH_DEG);

    printf("location %s: (%.3f, %.3f) local moho %.1f km\n", loc_name, lon, lat, local_moho);

    add_gll_layer(&ref, &ref_local, local_vs, local_xi, local_moho, local_topo);

    perturb_1d_model_SX(&ref_local, &a3d, R_PERTB_MIN, 6371000.0 - 1000.0 * local_moho, dlnVs_spl, dlnXi_spl);

    out_filename_len = strlen(loc_name) + strlen(out_file_base) + 1;
    out_filename = malloc(out_filename_len + 1);
    sprintf(out_filename, "%s.%s", out_file_base, loc_name);

    write_model(out_filename, &ref_local);
    printf("wrote %s\n", out_filename);
  }

  return 0;
}
