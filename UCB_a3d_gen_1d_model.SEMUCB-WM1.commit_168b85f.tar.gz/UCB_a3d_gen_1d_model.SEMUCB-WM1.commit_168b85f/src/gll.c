#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <cminos.h>
#include <gll.h>

/* GLL node locations on the interval [-1.0, 1.0] */ 
const double gll_nodes[] = { - 1.0, - 0.654653671, 0.0, 0.654653671, 1.0 };

/* constants for crustal and ocean structure 
 * N.B. - all values are in kg-m-s */
const double q_k_crust = 99900.0;
const double q_m_crust = 300.0;
const double eta_crust = 1.0;
const double dr_max_crust = 0.5;
const double rho_ocean = 1.02;
const double vp_ocean  = 1.45;
const double q_k_ocean = 57822.5;
const double eta_ocean = 1.0;
const double dr_max_ocean = 0.05;
const double min_ocean_depth = 0.1;

/* polynomial coefficients for Brocher prediction of crustal vp and rho */
#define DEGREE_BROCHER 4
const double brocher_vp_coefs_vs[] = { 0.9409, 2.0947, - 0.8206, 0.2683, - 0.0251 };
const double brocher_rho_coefs_vp[] = { 1.6612, - 0.4721, 0.0671, - 0.0043, 0.000106 };

/* Explicitly defined Lagrange polynomials */
static inline double l_4_0( double x );
static inline double l_4_1( double x );
static inline double l_4_2( double x );
static inline double l_4_3( double x );
static inline double l_4_4( double x );

/* local function for Brocher vp and rho prediction */
static void 
brocher( double *vs, double *vp, double *rho )
{
  for ( int n = 0; n < DEGREE_GLL + 1; n++ )
    {
      vp[n] = brocher_vp_coefs_vs[0] +
              brocher_vp_coefs_vs[1] * vs[n] +
              brocher_vp_coefs_vs[2] * vs[n] * vs[n] +
              brocher_vp_coefs_vs[3] * vs[n] * vs[n] * vs[n] +
              brocher_vp_coefs_vs[4] * vs[n] * vs[n] * vs[n] * vs[n];
      rho[n] = vp[n] * ( brocher_rho_coefs_vp[0] +
			 brocher_rho_coefs_vp[1] * vp[n] +
			 brocher_rho_coefs_vp[2] * vp[n] * vp[n] +
			 brocher_rho_coefs_vp[3] * vp[n] * vp[n] * vp[n] +
			 brocher_rho_coefs_vp[4] * vp[n] * vp[n] * vp[n] * vp[n] );
    }
}


/* map from a limited number of unique vs and xi values to all DEGREE_GLL + 1 */
static void
map_vs( double *vs_unique, double *vs )
{
  vs[0] = vs_unique[0];
  vs[1] = vs_unique[1];
  vs[2] = vs_unique[2];
  vs[3] = vs_unique[3];
  vs[4] = vs_unique[4];
}

static void
map_xi( double *xi_unique, double *xi )
{
  xi[0] = xi_unique[0];
  xi[1] = xi_unique[1];
  xi[2] = xi_unique[2];
  xi[3] = xi_unique[3];
  xi[4] = xi_unique[4];
}

/* replaces the upper portion of a cminos model with a gll-defined version */
void 
add_gll_layer( model_t *sref, model_t *dref, double *vs_unique, double *xi_unique, double moho, double topo )
{
  int num_ocean_knots, num_crust_knots, index_sref_mantle_max, index_dref;
  double bath = - topo;
  double dr_ocean, dr_crust, r_moho_meters;
  double vs[DEGREE_GLL + 1], xi[DEGREE_GLL + 1];
  double vsv[DEGREE_GLL + 1], vsh[DEGREE_GLL + 1], rho[DEGREE_GLL + 1], vp[DEGREE_GLL + 1], mantle_moho[9];

  /* expand vs nodal values from unique values */
  map_vs( vs_unique, vs );
  map_xi( xi_unique, xi );

  /* sanitize bathymetry */
  if ( bath < 0.0 )
    bath = 0.0;
  else if ( bath < min_ocean_depth )
    bath = min_ocean_depth;

  /* predict isotropic vp and density */
  brocher( vs, vp, rho );

  /* calculate nodal vsv, vsh */
  for ( int n = 0; n < DEGREE_GLL + 1; n++ )
    {
      vsv[n] = sqrt( 3.0 * vs[n] * vs[n] / ( 2.0 + xi[n] ) );
      vsh[n] = sqrt( xi[n] * vsv[n] * vsv[n] );
    }

  /* discretization of the tabular crustal model */
  num_crust_knots = ceil( ( moho - bath ) / dr_max_crust ) + 1;
  dr_crust = ( moho - bath ) / ( num_crust_knots - 1 );

  /* moho radius */
  r_moho_meters = sref->r[sref->npts - 1] - 1000.0 * moho;

  /* determine mantle-side moho properties */
  for ( int k = 0; k < sref->npts - 1; k++ )
    if ( sref->r[k] < r_moho_meters && sref->r[k+1] >= r_moho_meters )
      {
	double beta = ( r_moho_meters - sref->r[k] ) / ( sref->r[k+1] - sref->r[k] );
	mantle_moho[0] = r_moho_meters;
	mantle_moho[1] = ( 1.0 - beta ) * sref->rho[k] + beta * sref->rho[k+1];
	mantle_moho[2] = ( 1.0 - beta ) * sref->vpv[k] + beta * sref->vpv[k+1];
	mantle_moho[3] = ( 1.0 - beta ) * sref->vsv[k] + beta * sref->vsv[k+1];
	mantle_moho[4] = ( 1.0 - beta ) * sref->qk[k] + beta * sref->qk[k+1];
	mantle_moho[5] = ( 1.0 - beta ) * sref->qmu[k] + beta * sref->qmu[k+1];
	mantle_moho[6] = ( 1.0 - beta ) * sref->vph[k] + beta * sref->vph[k+1];
	mantle_moho[7] = ( 1.0 - beta ) * sref->vsh[k] + beta * sref->vsh[k+1];
	mantle_moho[8] = ( 1.0 - beta ) * sref->eta[k] + beta * sref->eta[k+1];
	index_sref_mantle_max = k;
	break;
      }

  /* tabular ocean model discretization */
  if ( bath > 0.0 )
    {
      num_ocean_knots = ceil( bath / dr_max_ocean ) + 1;
      dr_ocean = bath / ( num_ocean_knots - 1 );
      //printf("bath = %f, num_ocean_knots = %i\n", bath, num_ocean_knots);
    }
  else
    num_ocean_knots = 0;

  /* fill in the mantle */
  index_dref = 0;
  for ( int k = 0; k < index_sref_mantle_max + 1; k++ )
    {
      dref->r[index_dref]   = sref->r[k];
      dref->rho[index_dref] = sref->rho[k];
      dref->vpv[index_dref] = sref->vpv[k];
      dref->vsv[index_dref] = sref->vsv[k];
      dref->qk[index_dref]  = sref->qk[k];
      dref->qmu[index_dref] = sref->qmu[k];
      dref->vph[index_dref] = sref->vph[k];
      dref->vsh[index_dref] = sref->vsh[k];
      dref->eta[index_dref] = sref->eta[k];
      index_dref += 1;
    }

  /* add the top-most mantle layer */
  dref->r[index_dref]   = mantle_moho[0];
  dref->rho[index_dref] = mantle_moho[1];
  dref->vpv[index_dref] = mantle_moho[2];
  dref->vsv[index_dref] = mantle_moho[3];
  dref->qk[index_dref]  = mantle_moho[4];
  dref->qmu[index_dref] = mantle_moho[5];
  dref->vph[index_dref] = mantle_moho[6];
  dref->vsh[index_dref] = mantle_moho[7];
  dref->eta[index_dref] = mantle_moho[8];
  index_dref += 1;
  
  /* add the crust */
  for ( int k = 0; k < num_crust_knots; k++ )
    {
      double r = sref->r[sref->npts-1] - 1000.0 * ( moho - k * dr_crust );
      double x = - 1.0 + k * 2.0 / ( num_crust_knots - 1 );
      double l[DEGREE_GLL + 1];
      l[0] = l_4_0( x );
      l[1] = l_4_1( x );
      l[2] = l_4_2( x );
      l[3] = l_4_3( x );
      l[4] = l_4_4( x );
      dref->r[index_dref]   = r;
      dref->qk[index_dref]  = q_k_crust;
      dref->qmu[index_dref] = q_m_crust;
      dref->eta[index_dref] = eta_crust;
      dref->rho[index_dref] = 0.0;
      dref->vpv[index_dref] = 0.0;
      dref->vsv[index_dref] = 0.0;
      dref->vph[index_dref] = 0.0;
      dref->vsh[index_dref] = 0.0;
      for ( int n = 0; n < DEGREE_GLL + 1; n++ )
	{
	  dref->rho[index_dref] += 1000.0 * rho[n] * l[n];
	  dref->vpv[index_dref] += 1000.0 * vp[n] * l[n];
	  dref->vsv[index_dref] += 1000.0 * vsv[n] * l[n];
	  dref->vph[index_dref] += 1000.0 * vp[n] * l[n];
	  dref->vsh[index_dref] += 1000.0 * vsh[n] * l[n];
	}
      index_dref += 1;
    }

  /* add the ocean */
  for ( int k = 0; k < num_ocean_knots; k++ )
    {
      double r = sref->r[sref->npts-1] - 1000.0 * ( bath - k * dr_ocean );
      dref->r[index_dref]   = r;
      dref->rho[index_dref] = 1000.0 * rho_ocean;
      dref->vpv[index_dref] = 1000.0 * vp_ocean;
      dref->vsv[index_dref] = 0.0;
      dref->qk[index_dref]  = q_k_ocean;
      dref->qmu[index_dref] = 0.0;
      dref->vph[index_dref] = 1000.0 * vp_ocean;
      dref->vsh[index_dref] = 0.0;
      dref->eta[index_dref] = eta_ocean;
      index_dref += 1;
    }
  
  /* finish with the header */
  strcpy( dref->model_name, sref->model_name );
  dref->ifanis = sref->ifanis;
  dref->tref   = sref->tref;
  dref->ifdeck = sref->ifdeck;
  dref->npts   = index_dref;
  dref->icb    = sref->icb;
  dref->cmb    = sref->cmb;
  dref->noc    = num_ocean_knots;
}



/* Lagrange polynomials explicitly defined below */


static inline double 
l_4_0( double x )
{
  return ( x - gll_nodes[1] ) * ( x - gll_nodes[2] ) * ( x - gll_nodes[3] ) * ( x - gll_nodes[4] ) / 
         ( ( gll_nodes[0] - gll_nodes[1] ) * ( gll_nodes[0] - gll_nodes[2] ) * 
           ( gll_nodes[0] - gll_nodes[3] ) * ( gll_nodes[0] - gll_nodes[4] ) );
}

static inline double 
l_4_1( double x )
{
  return ( x - gll_nodes[0] ) * ( x - gll_nodes[2] ) * ( x - gll_nodes[3] ) * ( x - gll_nodes[4] ) / 
         ( ( gll_nodes[1] - gll_nodes[0] ) * ( gll_nodes[1] - gll_nodes[2] ) * 
           ( gll_nodes[1] - gll_nodes[3] ) * ( gll_nodes[1] - gll_nodes[4] ) );
}

static inline double 
l_4_2( double x )
{
  return ( x - gll_nodes[0] ) * ( x - gll_nodes[1] ) * ( x - gll_nodes[3] ) * ( x - gll_nodes[4] ) / 
         ( ( gll_nodes[2] - gll_nodes[0] ) * ( gll_nodes[2] - gll_nodes[1] ) * 
           ( gll_nodes[2] - gll_nodes[3] ) * ( gll_nodes[2] - gll_nodes[4] ) );
}

static inline double 
l_4_3( double x )
{
  return ( x - gll_nodes[0] ) * ( x - gll_nodes[1] ) * ( x - gll_nodes[2] ) * ( x - gll_nodes[4] ) / 
         ( ( gll_nodes[3] - gll_nodes[0] ) * ( gll_nodes[3] - gll_nodes[1] ) * 
           ( gll_nodes[3] - gll_nodes[2] ) * ( gll_nodes[3] - gll_nodes[4] ) );
}

static inline double 
l_4_4( double x )
{
  return ( x - gll_nodes[0] ) * ( x - gll_nodes[1] ) * ( x - gll_nodes[2] ) * ( x - gll_nodes[3] ) / 
         ( ( gll_nodes[4] - gll_nodes[0] ) * ( gll_nodes[4] - gll_nodes[1] ) * 
           ( gll_nodes[4] - gll_nodes[2] ) * ( gll_nodes[4] - gll_nodes[3] ) );
}


