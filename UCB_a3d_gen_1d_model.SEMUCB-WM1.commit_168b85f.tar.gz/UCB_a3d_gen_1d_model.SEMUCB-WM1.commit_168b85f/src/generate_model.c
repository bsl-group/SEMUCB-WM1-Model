#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <cminos.h>
#include <a3d_model.h>
#include <gll.h>
#include <partial.h>
#include <mpi.h>

/* uncomment to have each process report the time in seconds for each model -
 * very noisy! you probably only want this for debugging */
/* #define REPORT_TIMINGS */

/* epsilon perturbations for FD partials */
#define DELTA_VS_BSPL_COEF 0.005
#define DELTA_XI_BSPL_COEF 0.005

/* MINOS configuration - fundamental mode hard-wired in calculate_synthetics( ) */
#define MINOS_EPS 1.e-9
#define MINOS_WGRAV 41.0
#define MINOS_LMIN 0
#define MINOS_LMAX 700
#define MINOS_WMIN 6.0
#define MINOS_WMAX 41.0


static void
calculate_synthetics( double *U, double *c, double *T, model_t *ref, int num_periods, int jcom );

static void
calculate_jacobian_vs_bsplines( double *T, double *JU, double *Jc, double *U_0, double *c_0, model_t *ref,
                                a3d_model_t *a3d, double *dlnVs_spl, double *dlnXi_spl,
                                double moho, int num_periods, int jcom );

static void
calculate_jacobian_xi_bsplines( double *T, double *JU, double *Jc, double *U_0, double *c_0, model_t *ref,
                                a3d_model_t *a3d, double *dlnVs_spl, double *dlnXi_spl,
                                double moho, int num_periods, int jcom );


void
generate_jacobians( model_t *sref, a3d_model_t *a3d, double *dlnVs_spl, double *dlnXi_spl,
                    double *unique_vs, double *unique_xi, double topo, double moho,
                    double *T, int num_periods, double *J_R_U, double *J_L_U, double *J_R_c, double *J_L_c,
                    double *Usyn_R, double *Usyn_L, double *csyn_R, double *csyn_L,
                    int rank, FILE *f_log )
{
  model_t ref_local; /* local 1D model structure */

#ifdef REPORT_TIMINGS
  double wt = - MPI_Wtime();
#endif

  /* initialize the local 1D model with the GLL crustal layer */
  add_gll_layer( sref, &ref_local, unique_vs, unique_xi, moho, topo );

  /* add the mantle current mantle perturbation */
  perturb_1d_model_SX( &ref_local, a3d, R_PERTB_MIN, 6371000.0 - 1000.0 * moho, dlnVs_spl, dlnXi_spl );

  /* calculate initial synethics */
  calculate_synthetics( Usyn_L, csyn_L, T, &ref_local, num_periods, 2 );
  calculate_synthetics( Usyn_R, csyn_R, T, &ref_local, num_periods, 3 );

  if ( J_L_U != NULL && J_R_U != NULL && J_L_c != NULL && J_R_c != NULL )
    {
      /* re-initialize the local 1D model with the GLL crustal layer (mantle remains unperturbed )*/
      add_gll_layer( sref, &ref_local, unique_vs, unique_xi, moho, topo );

      /* ... get the FD approximate Jacobians calculated in the current model ... */

      /* isotropic Vs */
      calculate_jacobian_vs_bsplines( T,
          J_L_U, J_L_c,
          Usyn_L, csyn_L, &ref_local, a3d, dlnVs_spl, dlnXi_spl, moho, num_periods, 2 );
      calculate_jacobian_vs_bsplines( T,
          J_R_U, J_R_c,
          Usyn_R, csyn_R, &ref_local, a3d, dlnVs_spl, dlnXi_spl, moho, num_periods, 3 );

      /* Xi */
      calculate_jacobian_xi_bsplines( T,
          &J_L_U[num_periods * NUM_BSPLINES_INVERT], &J_L_c[num_periods * NUM_BSPLINES_INVERT],
          Usyn_L, csyn_L, &ref_local, a3d, dlnVs_spl, dlnXi_spl, moho, num_periods, 2 );
      calculate_jacobian_xi_bsplines( T,
          &J_R_U[num_periods * NUM_BSPLINES_INVERT], &J_R_c[num_periods * NUM_BSPLINES_INVERT],
          Usyn_R, csyn_R, &ref_local, a3d, dlnVs_spl, dlnXi_spl, moho, num_periods, 3 );
    }

#ifdef REPORT_TIMINGS
  wt += MPI_Wtime();
  printf( "Computed one set of partials in %.3f seconds\n", wt ); fflush( stdout );
#endif
}


void
calculate_synthetics( double *U, double *c, double *T, model_t *ref, int num_periods, int jcom )
{
  /* set the minos model to the preturbed model */
  set_minos_model( ref );

  /* minos configuration */
  configure_minos( MINOS_EPS, MINOS_WGRAV, jcom, MINOS_LMIN, MINOS_LMAX, MINOS_WMIN, MINOS_WMAX, 0, 0 );

  /* run the initial model */
  run_minos( num_periods, T, U, c );
}


void
calculate_jacobian_vs_bsplines( double *T, double *JU, double *Jc, double *U_0, double *c_0, model_t *ref,
                                a3d_model_t *a3d, double *dlnVs_spl, double *dlnXi_spl,
                                double moho, int num_periods, int jcom )
{
  model_t ref_pertb;
  double *U_1, *c_1;

  /* allocate space for perturbed group velocities */
  U_1 = malloc( num_periods * sizeof( double ) );
  c_1 = malloc( num_periods * sizeof( double ) );

  /* minos configuration */
  configure_minos( MINOS_EPS, MINOS_WGRAV, jcom, MINOS_LMIN, MINOS_LMAX, MINOS_WMIN, MINOS_WMAX, 0, 0 );

  /* loop over vs values */
  for ( int k = BSPL_PARTIAL_MIN; k <= BSPL_PARTIAL_MAX; k++ )
    {
      /* store initial value of perturbed coef */
      double vs_0 = dlnVs_spl[k];

      /* perturb the vs model */
      dlnVs_spl[k] += DELTA_VS_BSPL_COEF;

      /* local copy for perturbation */
      copy_model( ref, &ref_pertb );

      /* add the mantle perturbation */
      perturb_1d_model_SX( &ref_pertb, a3d, R_PERTB_MIN, 6371000.0 - 1000.0 * moho, dlnVs_spl, dlnXi_spl );

      /* set the perturbed coef back to its original value */
      dlnVs_spl[k] = vs_0;

      /* set the minos model to ref_pertb */
      set_minos_model( &ref_pertb );

      /* run the perturbed model */
      run_minos( num_periods, T, U_1, c_1 );

      /* recover FD partial derivatives */
      for ( int it = 0; it < num_periods; it++ )
        {
          JU[( k - BSPL_PARTIAL_MIN ) * num_periods + it] = ( U_1[it] - U_0[it] ) / DELTA_VS_BSPL_COEF;
          Jc[( k - BSPL_PARTIAL_MIN ) * num_periods + it] = ( c_1[it] - c_0[it] ) / DELTA_VS_BSPL_COEF;
        }
    }

  /* free group velocity arrays */
  free( U_1 );
  free( c_1 );
}


void
calculate_jacobian_xi_bsplines( double *T, double *JU, double *Jc, double *U_0, double *c_0, model_t *ref,
                                a3d_model_t *a3d, double *dlnVs_spl, double *dlnXi_spl,
                                double moho, int num_periods, int jcom )
{
  model_t ref_pertb;
  double *U_1, *c_1;

  /* allocate space for perturbed group velocities */
  U_1 = malloc( num_periods * sizeof( double ) );
  c_1 = malloc( num_periods * sizeof( double ) );

  /* minos configuration */
  configure_minos( MINOS_EPS, MINOS_WGRAV, jcom, MINOS_LMIN, MINOS_LMAX, MINOS_WMIN, MINOS_WMAX, 0, 0 );

  /* loop over vs values */
  for ( int k = BSPL_PARTIAL_MIN; k <= BSPL_PARTIAL_MAX; k++ )
    {
      /* store initial value of perturbed coef */
      double xi_0 = dlnXi_spl[k];

      /* perturb the xi model */
      dlnXi_spl[k] += DELTA_XI_BSPL_COEF;

      /* local copy for perturbation */
      copy_model( ref, &ref_pertb );

      /* add the mantle perturbation */
      perturb_1d_model_SX( &ref_pertb, a3d, R_PERTB_MIN, 6371000.0 - 1000.0 * moho, dlnVs_spl, dlnXi_spl );

      /* set the perturbed coef back to its original value */
      dlnXi_spl[k] = xi_0;

      /* set the minos model to ref_pertb */
      set_minos_model( &ref_pertb );

      /* run the perturbed model */
      run_minos( num_periods, T, U_1, c_1 );

      /* recover FD partial derivatives */
      for ( int it = 0; it < num_periods; it++ )
        {
          JU[( k - BSPL_PARTIAL_MIN ) * num_periods + it] = ( U_1[it] - U_0[it] ) / DELTA_XI_BSPL_COEF;
          Jc[( k - BSPL_PARTIAL_MIN ) * num_periods + it] = ( c_1[it] - c_0[it] ) / DELTA_XI_BSPL_COEF;
        }
    }

  /* free group velocity arrays */
  free( U_1 );
  free( c_1 );
}
