#include <stdio.h>
#include <math.h>

#define PI 3.141592653589793
#define DEG2RAD 0.017453292519943295

static double
haversin(double theta)
{
  return 0.5 * (1.0 - cos(theta));
}

static double
dist(double lat0, double lon0, double lat1, double lon1)
{
  return 2.0 * asin(sqrt(haversin(lat1 - lat0) + cos(lat1) *  cos(lat0) * haversin(lon1 - lon0)));
}

double
cos_interp(double *lats, double *lons, double *field, int n, double lat, double lon, double width)
{
  int nsum;
  double sum, wsum;
  width *= DEG2RAD;
  nsum = 0;
  sum = wsum = 0.0;
  for (int i = 0; i < n; i++) {
    double d, w;
    d = dist(DEG2RAD * lats[i], DEG2RAD * lons[i],
             DEG2RAD * lat, DEG2RAD * lon);
    if (d < 0.5 * width) {
      w = 0.5 * (1.0 + cos(PI * d / (0.5 * width)));
      sum += w * field[i];
      wsum += w;
      nsum += 1;
    }
  }
  return nsum > 0 ? sum / wsum : 0.0;
}
