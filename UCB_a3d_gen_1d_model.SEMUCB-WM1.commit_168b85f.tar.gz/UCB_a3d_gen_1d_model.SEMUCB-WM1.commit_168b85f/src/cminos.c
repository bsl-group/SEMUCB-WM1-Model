#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <cminos.h>

void 
load_model( char *model_file_name, model_t *ref )
{
  FILE *f_in;
  char line[MODEL_LINE_LEN];

  if ( ( f_in = fopen( model_file_name, "r" ) ) == NULL )
    {
      printf( "[ load_model ] Error: cannot open model file %s - %s\n", model_file_name, strerror( errno ) );
      exit( 1 );
    }

  fgets( line, MODEL_LINE_LEN, f_in );
  sscanf( line, "%s", ref->model_name );
  fgets( line, MODEL_LINE_LEN, f_in );
  sscanf( line, "%i %lf %i", &ref->ifanis, &ref->tref, &ref->ifdeck );
  fgets( line, MODEL_LINE_LEN, f_in );
  sscanf( line, "%i %i %i %i", &ref->npts, &ref->icb, &ref->cmb, &ref->noc );
  
  if ( ref->npts > MODEL_NPTS_MAX )
    {
      printf( "[ load_model ] Error: MODEL_NPTS_MAX is too small\n" );
      exit( 1 );
    }

  for ( int ipt = 0; ipt < ref->npts; ipt++ )
      fscanf( f_in, "%lf %lf %lf %lf %lf %lf %lf %lf %lf", 
	      &ref->r[ipt],  &ref->rho[ipt], &ref->vpv[ipt], &ref->vsv[ipt],
	      &ref->qk[ipt], &ref->qmu[ipt], &ref->vph[ipt], &ref->vsh[ipt],
	      &ref->eta[ipt] );

  fclose( f_in );
}

void 
write_model( char *model_file_name, model_t *ref )
{
  FILE *f_in;

  if ( ( f_in = fopen( model_file_name, "w" ) ) == NULL )
    {
      printf( "[ load_model ] Error: cannot open model file %s - %s\n", model_file_name, strerror( errno ) );
      exit( 1 );
    }

  fprintf( f_in, "%s\n", ref->model_name );
  fprintf( f_in, "%i %f %i\n", ref->ifanis, ref->tref, ref->ifdeck );
  fprintf( f_in, "%i %i %i %i\n", ref->npts, ref->icb, ref->cmb, ref->noc );
  
  for ( int ipt = 0; ipt < ref->npts; ipt++ )
      fprintf( f_in, "%8.0f%9.2f%9.2f%9.2f%9.1f%9.1f%9.2f%9.2f%9.5f\n", 
	      ref->r[ipt],  ref->rho[ipt], ref->vpv[ipt], ref->vsv[ipt],
	      ref->qk[ipt], ref->qmu[ipt], ref->vph[ipt], ref->vsh[ipt],
	      ref->eta[ipt] );

  fclose( f_in );
}

void 
copy_model( model_t *sref, model_t *dref )
{
  strcpy( dref->model_name, sref->model_name );
  dref->ifanis = sref->ifanis;
  dref->tref   = sref->tref;
  dref->ifdeck = sref->ifdeck;
  dref->npts   = sref->npts;
  dref->icb    = sref->icb;
  dref->cmb    = sref->cmb;
  dref->noc    = sref->noc;
  
  for ( int ipt = 0; ipt < dref->npts; ipt++ )
    {
      dref->r[ipt]   = sref->r[ipt];
      dref->rho[ipt] = sref->rho[ipt];
      dref->vpv[ipt] = sref->vpv[ipt];
      dref->vsv[ipt] = sref->vsv[ipt];
      dref->qk[ipt]  = sref->qk[ipt];
      dref->qmu[ipt] = sref->qmu[ipt];
      dref->vph[ipt] = sref->vph[ipt];
      dref->vsh[ipt] = sref->vsh[ipt];
      dref->eta[ipt] = sref->eta[ipt];
    }
}
